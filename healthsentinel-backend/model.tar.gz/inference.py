import joblib
import os
import json

def model_fn(model_dir):
    # Load your model from the directory
    model = joblib.load(os.path.join(model_dir, "model.pkl"))
    return model

def input_fn(request_body, request_content_type):
    # Parse the incoming JSON request
    if request_content_type == 'application/json':
        input_data = json.loads(request_body)
        return input_data
    return None

def predict_fn(input_data, model):
    # Make prediction using your loaded model
    # Note: Adjust the input format to match what your model expects
    return model.predict([input_data])
